using System;
using System.Collections.Generic;
using TouchToolkit.GestureProcessor.Objects;
using TouchToolkit.GestureProcessor.PrimitiveConditions.Validators;
using TouchToolkit.GestureProcessor.PrimitiveConditions.Objects;

namespace $rootnamespace$
{
    public class $safeitemname$Validator : IPrimitiveConditionValidator
    {
        #region IPrimitiveConditionValidator Members

		public void Init(IPrimitiveConditionData ruleData)
        {
            throw new NotImplementedException();
        }

        public bool Equals(IPrimitiveConditionValidator rule)
        {
            throw new NotImplementedException();
        }

        public ValidSetOfPointsCollection Validate(List<TouchPoint2> points)
        {
            throw new NotImplementedException();
        }

        public ValidSetOfPointsCollection Validate(ValidSetOfPointsCollection sets)
        {
            throw new NotImplementedException();
        }

        public IPrimitiveConditionData GenerateRuleData(List<TouchPoint2> points)
        {
            throw new NotImplementedException();
        }
        #endregion
	}
}
