using System;
using TouchToolkit.GestureProcessor.PrimitiveConditions.Objects;

namespace $rootnamespace$
{
    public class $safeitemname$ : : IPrimitiveConditionData
    {
        #region IPrimitiveConditionData Members

        public bool Equals(IPrimitiveConditionData value)
        {
            throw new NotImplementedException();
        }

        public void Union(IPrimitiveConditionData value)
        {
            throw new NotImplementedException();
        }

        public string ToGDL()
        {
            throw new NotImplementedException();
        }

        #endregion
	}
}