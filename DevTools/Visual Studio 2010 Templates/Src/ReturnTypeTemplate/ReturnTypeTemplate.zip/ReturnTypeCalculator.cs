using System;
using TouchToolkit.GestureProcessor.ReturnTypes;
using TouchToolkit.GestureProcessor.Objects;

namespace $rootnamespace$
{
    public class $safeitemname$Calculator : IReturnTypeCalculator
    {
		#region IReturnTypeCalculator Members

        public IReturnType Calculate(ValidSetOfTouchPoints set)
        {
            throw new NotImplementedException();
        }

        #endregion    
	}
}
