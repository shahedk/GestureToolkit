using System;
using TouchToolkit.GestureProcessor.ReturnTypes;

namespace $rootnamespace$
{
    public class $safeitemname$ : IReturnType
    {
        
	}
}
