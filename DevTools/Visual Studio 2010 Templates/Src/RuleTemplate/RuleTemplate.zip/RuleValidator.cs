using System;
using System.Collections.Generic;
using TouchToolkit.GestureProcessor.Objects;
using TouchToolkit.GestureProcessor.Rules.Objects;
using TouchToolkit.GestureProcessor.Rules.RuleValidators;

namespace $rootnamespace$
{
    public class $safeitemname$Validator : IRuleValidator
    {

        #region IRuleValidator Members

        public void Init(IRuleData ruleData)
        {
            throw new NotImplementedException();
        }

        public bool Equals(IRuleValidator rule)
        {
            throw new NotImplementedException();
        }

        public ValidSetOfPointsCollection Validate(List<TouchPoint2> points)
        {
            throw new NotImplementedException();
        }

        public ValidSetOfPointsCollection Validate(ValidSetOfPointsCollection sets)
        {
            throw new NotImplementedException();
        }

        public IRuleData GenerateRuleData(List<TouchPoint2> points)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
