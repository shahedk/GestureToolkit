using System;
using TouchToolkit.GestureProcessor.Rules.Objects;

namespace $rootnamespace$
{
    public class $safeitemname$ : IRuleData
    {

        #region IRuleData Members

        public bool Equals(IRuleData value)
        {
            throw new NotImplementedException();
        }

        public void Union(IRuleData value)
        {
            throw new NotImplementedException();
        }

        public string ToGDL()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}